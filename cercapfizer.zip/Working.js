import React from 'react';
import { Audio } from "expo-av";
import { Linking, ScrollView, StyleSheet, Text, View, TextInput, TouchableOpacity, Picker } from 'react-native';
import md5 from 'md5';
import moment from 'moment';

const MAX_SEARCHES = 10 * 6;
const SEARCH_DELAY = 10;

export default class Working extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      working: true,
      finalStatus: null,
      token: null,
      cookies: null,
      messages: [],
      searchCount: 0,
      validServicePointsCodes: [],
      slot: null,
      readyToBook: false
    };
  }
  componentDidMount() {
    this.doLogin();
  }
  maybeRestartSearch() {
    const {
      halted,
      messages
    } = this.state;
    if (halted) return;
    if (this.state.searchCount < MAX_SEARCHES) {
      this.setState({
        slot: null,
        messages: [...this.state.messages, `❌ Nessuna disponibilità, riprovo fra ${SEARCH_DELAY} secondi...`]
      }, () => {
        this.timeout = setTimeout(() => {
          this.doSearchSlots();
        }, 1000 * SEARCH_DELAY);
      })
    } else {
      this.setState({
        slot: null,
        messages: [...this.state.messages, `❌ Raggiunto il massimo numero di tentativi consecutivi.`]
      }, this.halt);
    }
  }
  doSearchSlots() {
    const {
      token,
      cookies,
      searchCount,
      messages,
      halted
    } = this.state;
    if (halted) return;
    if (searchCount < MAX_SEARCHES) {
      this.setState({
        searchCount: searchCount + 1,
        messages: [...messages, `ℹ Tentativo n. ${searchCount + 1} / ${MAX_SEARCHES}`]
      }, () => {
        this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/search-resources",
        {
          "paymentSubject":"VAC",
          "priorityCode":"",
          "language":"it",
          "type":2,
          "maxDistance":0,
          "searchSynchro":false,
          "searchNear":false,
          "sameDiary":false,
          "maxResults":200,
          "weekdays":"1111111",
          "idExams":[{"encodingSystem":"VACC_LAZ"}],
          "startDate": moment().endOf('day').toISOString(),
        }, token, cookies)
        .then(async res => {
          // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
          return { body: await res.json() };
        })
        .then(
          ({body}) => {
            // console.log(body);
            const {
              vaccino,
              provincia
            } = this.props;
            const {
              validServicePointsCodes
            } = this.state;
            const {
              providers
            } = body;
            if (!providers) {
              // console.log(body);
              throw new Error('Not loaded');
            }
            const validProviders = providers.filter((prov) => {
              // if (prov.displayName.toUpperCase().indexOf('ASTR') < 0) {
              //   console.log(prov.displayName,prov.siteName);
              // }
              // console.log(JSON.stringify(prov));
              // return prov.displayName.toUpperCase().indexOf('JOHN') > -1;
              if (prov.examId === vaccino && validServicePointsCodes.indexOf(prov.siteId) > -1) {
                const {
                  slots
                } = prov;
                if (slots && slots.length > 0) {
                  const [firstSlot] = slots;
                  const { datetime } = firstSlot;
                  const dt = moment(datetime);
                  if (dt.isBefore(moment(this.props.maxdate, 'DD/MM/YYYY').endOf('day'))) {
                    console.log(dt.format('DD/MM/YYYY'), moment(this.props.maxdate, 'DD/MM/YYYY').endOf('day').format('DD/MM/YYYY'));
                    console.log(prov.examId, prov.displayName,prov.siteName, dt.format('DD/MM/YYYY HH:mm:ss'));
                    return true;
                  } else {
                    // console.log('Invalid date');
                    // console.log(prov.examId, prov.displayName,prov.siteName, dt.format('DD/MM/YYYY HH:mm:ss'));
                  }
                }
                return false;
              }
              return false;
            });
            if (validProviders && validProviders.length > 0) {
              // console.log('validProviders', validProviders);
              const [first] = validProviders;
              console.log('Got', first.siteName, moment(first.slots[0].datetime).format('DD/MM/YYYY HH:mm:ss'));
              this.setState({
                slot: first,
                messages: [...this.state.messages, `✅ Trovata disponibilità presso ${first.siteName} in data ${moment(first.slots[0].datetime).format('DD/MM/YYYY HH:mm:ss')}. Avvio prenotazione...`]
              }, this.doLockOne)
            } else {
              this.maybeRestartSearch();
            }
          }
        )
        .catch(
          (e) => {
            console.error(e);
            this.onError(e);
          }
        )
      })
    } else {
      console.log('No more tries!');
    }
  }
  doLockOne() {
    const {
      token,
      cookies,
      slot,
      halted
    } = this.state;
    if (halted) return;
    const body = {"paymentSubject":"VAC","idExams":[{"code":slot.examId,"encodingSystem":"VACC_LAZ","requestId":"A1"}],"startDate":moment().startOf('day').toISOString(),"diaryIds":{"diaryId":[slot.diaryId]}};
    this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/lock-resource", body, token, cookies)
    .then(async res => {
      // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
      return { body: await res.json() };
    })
    .then(
      ({body}) => {
        if (body && body.providers && body.providers.length > 0) {
          console.log('Got a valid lock one', body);
          this.setState({
            messages: [...this.state.messages, `✅ Prima fase a buon fine. Proseguo...`],
            lock1: body
          }, this.doLockTwo);
        } else {
          console.log('Invalid lock one', body);
          this.setState({
            messages: [...this.state.messages, `❌ Tentativo fallito`]
          }, this.maybeRestartSearch);

        }
      }
    )
    .catch(
      (e) => {
        console.error(e);
        this.onError(e);
      }
    )
  }
  doLockTwo() {
    const {
      token,
      cookies,
      slot,
      halted
    } = this.state;
    if (halted) return;
    if (slot.relatedProviders && slot.relatedProviders[0]) {
      const service = slot.relatedProviders[0];
      const body = {"paymentSubject":"VAC","idExams":[{"code":service.examId,"encodingSystem":"VACC_LAZ","requestId":"A1"}],"startDate":moment().endOf('day').toISOString(),"diaryIds":{"diaryId":[service.diaryId]}};
      this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/lock-resource", body, token, cookies)
      .then(async res => {
        // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
        return { body: await res.json() };
      })
      .then(
        ({body}) => {
          if (body && body.providers && body.providers.length > 0) {
            console.log('Got a valid lock two', body);
            this.setState({
              messages: [...this.state.messages, `✅ Seconda fase a buon fine. Conferma entro 60 secondi con il pulsante per avviare la prenotazione.`],
              lock2: body
            }, this.askBookConfirm);
          } else {
            console.log('Invalid lock two', body);
            this.setState({
              messages: [...this.state.messages, `❌ Tentativo fallito`]
            }, this.maybeRestartSearch);

          }
        }
      )
      .catch(
        (e) => {
          console.error(e);
          this.onError(e);
        }
      )
    } else {
      this.setState({
        messages: [...this.state.messages, `✅ Questo vaccino non richiede la fase due. Conferma entro 60 secondi con il pulsante per avviare la prenotazione.`]
      }, this.askBookConfirm);
    }
  }
  async askBookConfirm() {
    const {
      halted
    } = this.state;
    if (halted) return;
    this.setState({
      readyToBook: true,
    });
    const { sound } = await Audio.Sound.createAsync(
       require('./assets/beep.mp3')
    );
    await sound.playAsync();
  }
  doBook() {
    const {
      lock1,
      lock2,
      slot,
      halted,
      token,
      cookies
    } = this.state;
    if (halted) return;
    let bookingJson;
      if (lock2) {
        bookingJson = require('./booking.json');
        const secondService = slot.relatedProviders[0];
        const hs1 = slot.healthServices[0];
        const hs2 = secondService.healthServices[0];
        bookingJson.bookings[0].serviceId = slot.serviceId;
        bookingJson.bookings[1].serviceId = slot.serviceId;
        bookingJson.bookings[0].diaryId = slot.diaryId;
        bookingJson.bookings[1].diaryId = secondService.diaryId;
        bookingJson.bookings[0].siteName = slot.siteName;
        bookingJson.bookings[1].siteName = secondService.siteName;
        bookingJson.bookings[0].unitId = slot.unitId;
        bookingJson.bookings[1].unitId = secondService.unitId;
        bookingJson.bookings[0].slot = slot.slots[0];
        bookingJson.bookings[1].slot = secondService.slots[0];
        bookingJson.bookings[0].prescriptionItems[0].displayName = hs1.displayName;
        bookingJson.bookings[1].prescriptionItems[0].displayName = hs2.displayName;
        bookingJson.bookings[0].prescriptionItems[0].codes = hs1.codes;
        bookingJson.bookings[1].prescriptionItems[0].codes = hs2.codes;
        bookingJson.bookings[0].patientDetails.mobile = this.props.cellulare;
        bookingJson.bookings[1].patientDetails.mobile = this.props.cellulare;
        bookingJson.bookings[0].patientDetails.mail = this.props.email;
        bookingJson.bookings[1].patientDetails.mail = this.props.email;
        bookingJson.bookings[0].applicantDetails.mobile = this.props.cellulare;
        bookingJson.bookings[1].applicantDetails.mobile = this.props.cellulare;
      } else {
        bookingJson = require('./booking1.json');
        const hs1 = slot.healthServices[0];
        bookingJson.bookings[0].serviceId = slot.serviceId;
        bookingJson.bookings[0].diaryId = slot.diaryId;
        bookingJson.bookings[0].siteName = slot.siteName;
        bookingJson.bookings[0].unitId = slot.unitId;
        bookingJson.bookings[0].slot = slot.slots[0];
        bookingJson.bookings[0].prescriptionItems[0].displayName = hs1.displayName;
        bookingJson.bookings[0].prescriptionItems[0].codes = hs1.codes;
        bookingJson.bookings[0].patientDetails.mobile = this.props.cellulare;
        bookingJson.bookings[0].patientDetails.mail = this.props.email;
        bookingJson.bookings[0].applicantDetails.mobile = this.props.cellulare;
        // delete bookingJson.bookings[1];
      }
      console.log(bookingJson);
      this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/book-resources", bookingJson, token, cookies)
      .then(async res => {
        // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
        return { body: await res.json() };
      })
      .then(({ body }) => {
        console.log('Booking result', body);
        if (body && body.results && body.results.length > 0) {
          // console.log('Booked correctly!!');
          console.log(body);
          this.props.saveBooking(body);
          const {
            bookingCode
          } = body.results[0];
          this.setState({
            working: false,
            booking: body,
            messages: [...this.state.messages, `✅ Prenotazione avvenuta con successo!!! Il tuo numero di prenotazione è: ${bookingCode}. Salva uno screenshot di questa pagina per tua sicurezza e accedi al portale della Regione Lazio per scaricare il PDF della tua prenotazione. Dovresti ricevere a breve uno o due sms di conferma da parte della Regione Lazio sul numero di telefono indicato.`]
          }, this.fetchPdf);
        } else {
          console.log('retval', body);
          throw new Error('Unable to book!!!');
        }
      })
      .catch(
        (e) => {
          console.error(e);
          this.onError(e);
        }
      );
  }
  fetchPdf() {
    const {
      token,
      cookie,
      booking
    } = this.state;
    const postBody = {"contextID":"VACC_LAZ","language":"it","idBooking":booking.results[0].idBooking,"pdf":"true"};
    this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/search-bookings", bookingJson, token, cookies)
    .then(async res => {
      // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
      return { body: await res.json() };
    })
    .then(
      ({body}) => {
        console.log(body);
        if (body && body.bookings) {
          const myBooking = body.bookings[0];
        }
      }
    )
  }
  doCheckPatient() {
    const {
      cookies,
      token,
      halted
    } = this.state;
    if (halted) return;
    // https://prenotavaccino-covid.regione.lazio.it/rest/profile/check-patient
    this.setState({
      messages: [...this.state.messages, 'ℹ Verifica assistito in corso...']
    });
    this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/profile/check-patient", {"contextID":"VACC_LAZ","language":"it","paymentSubject":"VAC"}, token, cookies)
    .then(async res => {
      // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
      return { body: await res.json() };
    })
    .then(({ body }) => {
      // console.log(body);
      if (body && body.error) {
        this.setState({
          messages: [...this.state.messages, '❌Prenotazione non eseguibile. Impossibile proseguire.']
        }, this.halt);
      } else {
        // console.log('B', body);
        if (body) {
          this.setState({
            messages: [...this.state.messages, '✅ Prenotazione possibile. Avvio ricerca...']
          }, this.doSearchFacilities)
        } else {

        }
      }
    })
    .catch(
      (e) => {
        console.error(e);
        this.onError(e);
      }
    );
  }
  doSearchFacilities() {
    const {
      cookies,
      token,
      halted
    } = this.state;
    if (halted) return;
    const {
      vaccino,
      provincia
    } = this.props;
    // https://prenotavaccino-covid.regione.lazio.it/rest/profile/check-patient
    this.setState({
      messages: [...this.state.messages, 'ℹ Cerco i possibili centri vaccinali...']
    });
    this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/search-health-services", {"contextID":"VACC_LAZ","paymentSubject":"VAC","language":"it","cupCode": vaccino}, token, cookies)
    .then(async res => {
      // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
      return { body: await res.json() };
    })
    .then(({ body }) => {
      // console.log(body);
      if (!body || !Array.isArray(body)) {
        console.log('No body');
        throw new Error('Unable to load facilities');
      }
      const [response] = body;
      if (!response) {
        console.log('No response');
        throw new Error('Unable to load facilities');
      }
      const { codes } = response;
      if (!codes) {
        console.log('No codes');
        throw new Error('Unable to load facilities');
      }
      const [ code ] = codes;
      if (!code) {
        console.log('No code');
        throw new Error('Unable to load facilities');
      }
      const { servicePoints } = code;
      if (!servicePoints || servicePoints.length < 1) {
        this.setState({
          messages: [...this.state.messages, '❌ Nessun centro vaccinale disponibile...']
        }, this.halt);
      } else {
        const goodPoints = servicePoints.filter(sp => sp.districtName.indexOf(provincia) > -1);
        const validServicePointsCodes = goodPoints.map(sp => sp.servicePointCode);
        if (validServicePointsCodes.length > 0) {
          this.setState({
            validServicePointsCodes,
            messages: [...this.state.messages, `ℹ Trovato ${validServicePointsCodes.length} centri vaccinali nella provincia selezionata`]
          }, this.doSearchSlots);
        } else {
          this.setState({
            messages: [...this.state.messages, '❌ Nessun centro vaccinale disponibile nella provincia selezionata...']
          }, this.halt);
        }
      }
    })
    .catch(
      (e) => {
        console.error(e);
        this.onError(e);
      }
    );
  }
  doLogin() {
    // console.log('PROPS', this.props);
    const {
      codicefiscale,
      team
    } = this.props;
    const {
      halted
    } = this.state;
    if (halted) return;
    // return;
    let myteam = team;
    // if (team.indexOf('8038000') === 0) {
    //   myteam = myteam.substr(7);
    // }
    this.setState({
      messages: [...this.state.messages, 'ℹ Accesso in corso...']
    });
    this.doPostReq("https://prenotavaccino-covid.regione.lazio.it/rest/v2/authentication", {
      "contextID": "VACC_LAZ",
      "username":codicefiscale.toLowerCase(),
      "deviceSerialNumber":"303558731",
      "platform":"Browser",
      "platformVersion":"Windows NT 10.0",
      "model":"Chrome 90.0",
      "appVersion":"021102",
      "paymentSubject":"VAC",
      "password":md5(myteam),
      "passwordDecrypted":myteam
    })
    .then(async res => {
      // console.log('COOKIES', res.headers, res.headers.map['set-cookie']);
      const cookies = res.headers.map['set-cookie'];
      return { cookies, body: await res.json() };
    })
    .then(({cookies, body}) => {
      // console.log({
      //   "contextID": "VACC_LAZ",
      //   "username":codicefiscale.toLowerCase(),
      //   "deviceSerialNumber":"303558731",
      //   "platform":"Browser",
      //   "platformVersion":"Windows NT 10.0",
      //   "model":"Chrome 90.0",
      //   "appVersion":"021102",
      //   "paymentSubject":"VAC",
      //   "password":md5(myteam),
      //   "passwordDecrypted":myteam
      // });
      // console.log('BODY', body);
      // console.log(body);
      if (body && body.result) {
        this.setState({
          cookies,
          token: body.token,
          messages: [...this.state.messages, 'ℹ Accesso eseguito...']
        }, () => {
          this.doCheckPatient();
        });
      } else {
        // console.log(body);
        this.setState({
          messages: [...this.state.messages, '❌Accesso fallito...']
        }, this.halt());
      }
    })
    .catch(
      (e) => {
        this.onError(e);
      }
    )
  }
  halt() {
    this.setState({
      working: false,
      slot: null,
      lock1: null,
      lock2: null,
      readyToBook: false,
      halted: true,
      messages: [...this.state.messages, '❌ Ricerca interrotta. Torna indietro per ricominciare.']
    });
  }
  onError(e) {
    this.setState({
      working: false,
      finalStatus: e.message,
      messages: [...this.state.messages, '❌ Errore inatteso! Ricerca interrotta!']
    })
  }
  render(){
    const {
      working,
      messages,
      readyToBook
    } = this.state;
    const nMessages = 10;
    // ${Math.max(messages.length - nMessages + 1, 1) + pos})
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.logo}>troVAX</Text>
          <Text style={styles.logosmall}>Lazio</Text>
          <Text style={styles.logoverysmall}>by manu@cappelleri.net</Text>
        </View>
        <ScrollView style={styles.paragraph}>
          {messages.map((m, pos) => {
            return (
              <Text key={`${m}_${pos}`} style={{ width: '100%', marginBottom: 5, color: 'white' }}>
                {`${m}`}
              </Text>
            )
          }).reverse()}
        </ScrollView>
        {
          readyToBook
          ? (
            <TouchableOpacity style={styles.confirmBtn} onPress={async () => {
              this.setState({
                readyToBook: false
              }, this.doBook);
            }}
            >
            <Text style={styles.confirmText}>Esegui prenotazione</Text>
            </TouchableOpacity>
          )
          : null

        }
        {
          working
          ? (
            <TouchableOpacity style={styles.loginBtn} onPress={async () => {
              this.halt();
            }}
            >
            <Text style={styles.loginText}>Interrompi</Text>
            </TouchableOpacity>
          )
          : (
            <TouchableOpacity style={styles.loginBtn} onPress={async () => {
              if (this.timeout) {
                clearTimeout(this.timeout);
              }
              this.props.onStop();
            }}
            >
            <Text style={styles.loginText}>Indietro</Text>
            </TouchableOpacity>
          )
        }

      </View>
    );
  }
  doPostReq(url, body, token, cookies) {
    const options = {
      "headers": {
        "accept": "application/json",
        "accept-language": "en,it-IT;q=0.9,it;q=0.8,en-US;q=0.7",
        "cache-control": "no-cache",
        // "cookie": cookies,
        "content-type": "application/json; charset=UTF-8",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        // "token": token,
        "x-requested-with": "XMLHttpRequest"
      },
      "referrer": "https://prenotavaccino-covid.regione.lazio.it/main/booking/availability",
      "referrerPolicy": "strict-origin-when-cross-origin",
      // "body": '{"contextID":"VACC_LAZ","username":"dzinys73a48z504p","deviceSerialNumber":"303558731","platform":"Browser","platformVersion":"Windows NT 10.0","model":"Chrome 90.0","appVersion":"021102","paymentSubject":"VAC","password":"be3492617b630348b31ff6877418df7b","passwordDecrypted":"80380001200176728115"}',
      "method": "POST"
    };
    if (token) {
      options.headers.token = token;
    }
    if (cookies) {
      options.headers.cookies = cookies;
    }
    if (body) {
      options.body = JSON.stringify(body);
    }
    return fetch(url, options);
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#898a88',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    flex: 0,
    marginTop: 30,
    // height: "100%",
    // backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo:{
    fontWeight:"bold",
    fontSize:50,
    color:"#f0851d",
    marginBottom:5
  },
  logosmall: {
    fontWeight:"bold",
    fontSize:30,
    color:"#f0851d",
    marginBottom:5
  },
  logoverysmall: {
    fontWeight:"bold",
    fontSize:13,
    color:"#f0851d",
    marginBottom:5
  },
  inputView:{
    width:"100%",
    backgroundColor:"#ffffff",
    borderRadius:25,
    height:50,
    marginBottom:20,
    justifyContent:"center",
    padding:20
  },
  inputText:{
    height:50,
    color:"#003f5c"
  },
  forgot:{
    color:"white",
    fontSize:11
  },
  confirmBtn:{
    flex: 0,
    width:"80%",
    backgroundColor:"#5afbab",
    borderRadius:25,
    height:50,
    alignItems:"center",
    justifyContent:"center",
    marginTop:20,
    marginBottom:0
  },
  loginBtn:{
    width:"80%",
    backgroundColor:"#f0851d",
    borderRadius:25,
    height:50,
    alignItems:"center",
    justifyContent:"center",
    marginTop:20,
    marginBottom:40
  },
  loginText:{
    color:"white"
  },
  paragraph: {
    flex: 1,
    flexGrow: 1,
    width:"80%",
    color: 'white',
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    // backgroundColor:"grey",
  }
});